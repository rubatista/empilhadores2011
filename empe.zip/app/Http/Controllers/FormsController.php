<?php

namespace App\Http\Controllers;

use App\Mail\Contact;
use Illuminate\Support\Facades\Mail;

class FormsController extends Controller
{
    public function contact()
    {
        Mail::to('teste.ruben02@gmail.com')->send(new Contact());
    }
}
