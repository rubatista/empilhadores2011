@extends('layout.app')
@section('meta')
    <title>Contacto - Empilhadores2011</title>
    <meta name="description" content="drescrição de todos os produtos aqui" />
    <meta name="keywords" content="empilhadores, baterias empilhadores, garfos, porta-paletes" />
    <meta name="author" content="empilhadores2011">
    <meta property="og:type" content="website" />
    <meta property="og:title" content="Contact - Empilhadores2011" />
    <meta property="og:description" content="drescrição de todos os produtos aqui" />
    <meta property="og:url" content="http://www.empilhadores2011.net/produtos" />
    <meta property="og:site_name" content="Empilhadores2011" />
    <meta property="og:price:amount" content="0.0" />
    <meta property="og:price:currency" content="EU" />
    <meta property="og:image" content="http://www.circu.net/images/logo-circu-magical-furniture.png" />
@endsection

@section('head-includes')
@endsection

@section('main-content')
<div class="container pt-5">
  <div class="row m-0">
    <div class="col-lg-5 p-0">
      <h3>Conctatos</h3>
      <p>917910265</p>
      <p>empilhadores2011@hotmail.com</p>
      <h3>Oficina</h3>
      <p>Rua Avelino Sousa Marques nº663<br>4475-460 Nogueira da Maia, Porto</p>
      <h3>Sede</h3>
      <p>Rua Avelino Sousa Marques nº663<br>4475-460 Nogueira da Maia, Porto</p>
    </div>
    <div class="col-lg-7 p-0">
      <form method="post" action="{{ route('contact') }}">
        {{ csrf_field() }}
        <h3>Deixe aqui a sua Mensagem</h3>
       <div class="row">
            <div class="col-md-6">
                <div class="form-group py-1">
                    <input type="text" name="name" class="form-control" placeholder="Nome *" value="" />
                </div>
                <div class="form-group py-1">
                    <input type="text" name="email" class="form-control" placeholder="Email *" value="" />
                </div>
                <div class="form-group py-1">
                    <input type="text" name="phone" class="form-control" placeholder="Telemovel *" value="" />
                </div>
                <div class="form-group py-1">
                    <input type="submit" name="btnSubmit" class="btnContact" value="Enviar Mensagem" />
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group h-100">
                    <textarea name="message" class="form-control" placeholder="Mensagem *" style="width: 100%; height: 100%;"></textarea>
                </div>
            </div>
        </div>
    </form>
    </div>
  </div>
</div>
@endsection

@section('footer-includes')

@endsection
