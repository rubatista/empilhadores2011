<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container px-5">
      <a class="navbar-brand" href="/"><img style="width: 120px;" src="/img/logo.png"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
              <li class="nav-item"><a class="nav-link" href="<?php echo e(route('homepage')); ?>">Inicio</a></li>
              <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" id="navbarDropdownPortfolio" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Equipamentos</a>
                  <ul class="dropdown-menu" aria-labelledby="navbarDropdownPortfolio">
                      <li><a class="dropdown-item" href="<?php echo e(route('products')); ?>">Empilhadores</a></li>
                      <li><a class="dropdown-item" href="portfolio-overview.html">Stacker's</a></li>
                      <li><a class="dropdown-item" href="portfolio-overview.html">Porta-Paletes</a></li>
                  </ul>
              </li>
              <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" id="navbarDropdownBlog" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Serviços</a>
                  <ul class="dropdown-menu" aria-labelledby="navbarDropdownBlog">
                      <li><a class="dropdown-item" href="blog-home.html">Aluguer</a></li>
                      <li><a class="dropdown-item" href="blog-post.html">Assistência Técnica</a></li>
                      <li><a class="dropdown-item" href="blog-home.html">Inspeções</a></li>
                  </ul>
              </li>
              <li class="nav-item"><a class="nav-link" href="about.html">Peças</a></li>
              <li class="nav-item"><a class="nav-link" href="<?php echo e(route('contacto')); ?>">Contactos</a></li>
          </ul>
      </div>
  </div>
</nav><?php /**PATH /Users/rubenbaptista/Projects/empilhadores-2011/resources/views/includes/header.blade.php ENDPATH**/ ?>